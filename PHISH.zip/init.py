import discord
from discord.ext import commands
import tldextract
from utils.paginator import Pag
from utils.functions import *
import os

description = '''da'''

intents = discord.Intents.default()
# intents.messages = True
help_command = commands.DefaultHelpCommand(
    no_category = 'ai nevoie de ajutor?'
)
bot = commands.AutoShardedBot(command_prefix='xellz ', help_command= help_command, description=description, intents=intents)

setupdb()


with open('whitelist.txt', 'r') as file:
  whitelist = file.read().splitlines()

whitelist = [item for item in whitelist if not(item == '' or item.startswith('#'))]


@bot.event
async def on_ready():
  print(f'Logged in as {bot.user} (ID: {bot.user.id})')
  print('------')
  activity = discord.Activity(name="cf mane", type=3)
  await bot.change_presence(status=discord.Status.idle, activity=activity)

for filename in os.listdir('./cogs'):
  if filename.endswith('.py'):
    bot.load_extension(f'cogs.{filename[:-3]}')

@bot.event
async def on_message(message):
  await bot.process_commands(message)
  if message.author.bot:
    return
  # read blacklist.txt and whitelist.txt, and filter from there
  urllist = findurls(message.content)
  if urllist:
    for url in urllist:
      urlextract = tldextract.extract(url)
      # Filter by TLD and common strings
      if urlextract.suffix in ['gift','gifts'] or any(baddomainname in urlextract.domain for baddomainname in ['discordgift','discord-gift','discordnitro','discord-nitro']):
        if url.startswith(('http://', 'https://')):
          if urlextract.registered_domain not in whitelist and not checkurl(message.guild.id, urlextract.registered_domain, 'whitelist'):
            await deletemsg(message)
      # Filter by blacklist
      checkblacklisturl(message.guild.id,url)
      if checkblacklisturl(message.guild.id,url):
        if urlextract.registered_domain not in whitelist and not checkurl(message.guild.id, urlextract.registered_domain, 'whitelist'):
          await deletemsg(message)

# Check again on edit
@bot.event
async def on_message_edit(before, after):
	await on_message(after)

# For analytic purposes
@bot.event
async def on_guild_join(guild):
  channel = bot.get_channel(914397885129424976)
  await channel.send('[{0}] {1} ({2}members)'.format(len(bot.guilds), guild.name, guild.member_count))

@bot.event
async def ban (ctx, member:discord.User=None, reason =None):
    if member == None or member == ctx.message.author:
        await ctx.channel.send("nu te poti bana singur prostule")
        return
    if reason == None:
        reason = "pula"
    message = f"ai fost banat in {ctx.guild.name} for {reason}"
    await member.send(message)
    # await ctx.guild.ban(member, reason=reason)
    await ctx.channel.send(f"{member} e banat")

bot.run("Njk0MjQwNzU4MjE5NDA3NDQw.XoIwFw.sj_LC_72Jsdp0LqBFOtxDVda6bE")
